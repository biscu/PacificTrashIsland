var c;

class Particle {
  constructor() {
    this.x = mouseX;
    this.y = mouseY;
    this.vx = random(-1, 1);
    this.vy = random(-1, 1);
    this.letter = s[c];
    this.size = random(25,140);
    this.z = random (0,360);
    this.vz = random (-0.05,0.05);
    tot++;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;

    if ((this.x > width)||(this.x < 0)) {
      this.vx *= -1;
    }
    if ((this.y > height)||(this.y < 0)) {
      this.vy *= -1;
    }
      this.z += this.vz;
  }

  show() {
    noStroke();
    fill(255);
    textSize(this.size);
    textFont('Vollkorn');
    textAlign(CENTER);

    push();
    translate(this.x,this.y);
    rotate(this.z);
    text(this.letter, 0,0);
    pop();
  }
}

function pushLett() {
  var p = new Particle();

  if (c==0) {
    particlesA.push(p);
  }
  if (c==1) {
    particlesB.push(p);
  }
  if (c==2) {
    particlesC.push(p);
  }
  if (c==3) {
    particlesD.push(p);
  }
  if (c==4) {
    particlesE.push(p);
  }
  if (c==5) {
    particlesF.push(p);
  }
}

function showParticles() {
  for (var i = 0; i < particlesA.length; i++) {
    particlesA[i].show();
    particlesA[i].update();
  }
  for (var i = 0; i < particlesB.length; i++) {
    particlesB[i].show();
    particlesB[i].update();
  }

  for (var i = 0; i < particlesC.length; i++) {
    particlesC[i].show();
    particlesC[i].update();
  }

  for (var i = 0; i < particlesD.length; i++) {
    particlesD[i].show();
    particlesD[i].update();
  }

  for (var i = 0; i < particlesE.length; i++) {
    particlesE[i].show();
    particlesE[i].update();
  }

  for (var i = 0; i < particlesF.length; i++) {
    particlesF[i].show();
    particlesF[i].update();
  }
}
