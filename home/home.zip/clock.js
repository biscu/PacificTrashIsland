var frameTime = 0;

function clock() {
  push();
  translate(100, 100);
  rotate(-90);


  fill(255, 255, 255, 100);
  arc(0, 0, 100, 100, 0, 360);
  fill(255, 255, 255);
  arc(0, 0, 100, 100, 0, -frameTime*0.6);
  pop();
  frameTime ++;
}


function showTextEnd() {
  if (frameTime>=600) {
    fill('red');
    textSize(60);
    text('GAME OVER', width/2, height/2);
  }
}
