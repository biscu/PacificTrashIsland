function setup() {

  createCanvas(windowWidth,windowHeight);
  background(0);
  frameRate(20);
  angleMode(DEGREES);
}

function draw() {
  background('#001b2d');

  // start - SHOW PARTICLES
  pushLett();
  showParticles();
  // end - SHOW PARTICLES

  // start - SCORE
  c = round(random(0,11));
  perc = round((score/tot) * 100);
  countLett(); //in letters_array.js
  showTextScore();
  clock();
  
  // end - SCORE
}



function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
