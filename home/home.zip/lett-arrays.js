var s = ['A','B','C','D','E','F','G','H','I','L','M','N','O','P','Q','R','S','T','U','V','Z','1','2','3','4','5','6','7','8','9','0','è','@','#','ù'];

particlesA = [],
particlesB = [],
particlesC = [],
particlesD = [],
particlesE = [],
particlesF = [];

function countLett() {
  numA = particlesA.length;
  numB = particlesB.length;
  numC = particlesC.length;
  numD = particlesD.length;
  numE = particlesE.length;
  numF = particlesF.length;
}
