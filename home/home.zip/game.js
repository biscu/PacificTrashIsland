var tot = 0,
    score = 0,
    perc = 0;


function keyTyped() {
  if (key == 'a'){
     particlesA.splice(0,particlesA.length);
     score = score + numA;
  }
  if (key == 'b'){
     particlesB.splice(0,particlesB.length);
     score = score + numB;
  }
  if (key == 'c'){
     particlesC.splice(0,particlesC.length);
     score = score + numC;
  }
  if (key == 'd'){
     particlesD.splice(0,particlesD.length);
     score = score + numD;
  }
  if (key == 'e'){
     particlesE.splice(0,particlesE.length);
     score = score + numE;
  }
  if (key == 'f'){
     particlesF.splice(0,particlesF.length);
     score = score + numF;
  }
}



function showTextScore() {
  noStroke();
  fill('red');
  textSize(30);
  text('tot: ' + tot, 100,100);
  fill('green');
  text('score: ' + score, width-100,100);
  fill('yellow');
  text('perc: ' + perc + '%', width/2,height-100);
}
